import { Router } from 'express';
import authRoutes from './auth.routes';
import userRoutes from './user.routes';
import taskRoutes from './task.routes';

const router = Router();

router.use('/auth', authRoutes);     // /auth/register, /auth/login
router.use('/users', userRoutes);    // /users/me
router.use('/tasks', taskRoutes);    // /tasks

console.log("JWT_SECRET: ", process.env.JWT_SECRET);

export default router;

