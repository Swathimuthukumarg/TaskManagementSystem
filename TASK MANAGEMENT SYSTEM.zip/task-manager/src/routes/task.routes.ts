import { Router } from 'express';
import {
  createTask,
  deleteTask,
  getTasks,
  updateTask,
  getTaskById,
  markTaskComplete
} from '../controllers/task.controller';
import { authMiddleware } from '../middlewares/auth';
import { validate } from '../middlewares/validate';
import { createTaskSchema, updateTaskSchema } from '../validations/task.validation';

const router = Router();

router.use(authMiddleware); // Protect all task routes

router.post('/', validate(createTaskSchema), createTask);
router.get('/', getTasks);
router.get('/:id', getTaskById);
router.put('/:id', validate(updateTaskSchema), updateTask);
router.patch('/:id/complete', markTaskComplete)
router.delete('/:id', deleteTask);

export default router;


