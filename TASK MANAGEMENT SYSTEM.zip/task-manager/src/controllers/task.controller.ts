import { Request, Response } from "express";
import { AppDataSource } from "../config/data-source";
import { Task } from "../entities/Task";
import { User } from "../entities/User";

const taskRepo = AppDataSource.getRepository(Task);

export const createTask = async (req: Request, res: Response) => {
  const userId = (req as any).user?.userId;

  if (!userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const user = await AppDataSource.getRepository(User).findOneBy({ id: userId });

  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }

  const { title, description } = req.body;
  const task = taskRepo.create({ title, description, user });
  await taskRepo.save(task);

  res.status(201).json(task);
};

export const getTasks = async (req: Request, res: Response) => {
  const userId = (req as any).user?.userId;

  if (!userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const tasks = await taskRepo.find({
    where: { user: { id: userId } },
  });

  res.json(tasks);
};

export const getTaskById = async (req: Request, res: Response) => {
  const userId = (req as any).user?.userId;
  const taskId = Number(req.params.id);

  if (!userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  if (isNaN(taskId)) {
    return res.status(400).json({ message: "Invalid Task ID" });
  }

  try {
    const task = await taskRepo.findOne({
      where: {
        id: taskId,
        user: { id: userId }
      },
      relations: ['user']
    });

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    res.status(200).json(task);
  } catch (err) {
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const updateTask = async (req: Request, res: Response) => {
  const task = await taskRepo.findOneBy({ id: +req.params.id });

  if (!task) {
    return res.status(404).json({ message: "Task not found" });
  }

  task.title = req.body.title || task.title;
  task.description = req.body.description || task.description;

  await taskRepo.save(task);

  res.json(task);
};

export const markTaskComplete = async (req: Request, res: Response) => {
  const taskId = Number(req.params.id);
  const userId = (req as any).user?.userId;

  if (isNaN(taskId)) {
    return res.status(400).json({ message: "Invalid Task ID" });
  }

  try {
    const task = await taskRepo.findOne({
      where: { id: taskId, user: { id: userId } },
      relations: ['user']
    });

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    task.completed = true;
    await taskRepo.save(task);

    res.status(200).json({ message: "Task marked as complete", task });
  } catch (error) {
    console.error("Error updating task:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

export const deleteTask = async (req: Request, res: Response) => {
  await taskRepo.delete(+req.params.id);
  res.json({ message: "Task deleted successfully" });
};
