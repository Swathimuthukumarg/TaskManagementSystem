import { Request, Response } from 'express';

export const getProfile = async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    // Omit password before sending user details
    const { password, ...userData } = req.user;

    return res.status(200).json(userData);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};
