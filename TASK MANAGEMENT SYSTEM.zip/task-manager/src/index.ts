// src/index.ts
import dotenv from 'dotenv';
dotenv.config(); // ✅ Add this at the top

import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import router from './routes';
import { AppDataSource } from './config/data-source';
/// <reference path="./types/express/index.d.ts" />

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(bodyParser.json());

app.use('/api', router); // All routes start with /api

AppDataSource.initialize()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server is running at http://localhost:${PORT}`);
    });
  })
  .catch((err) => console.error('Data Source Init Error:', err));
